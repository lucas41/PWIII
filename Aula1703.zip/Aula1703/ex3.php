<?php

$n1 = 8;

if ($n1%10 == 0){
    echo "divisivel por 10\n";
}
if ($n1%5 == 0){
    echo "divisivel por 5\n";
}
if ($n1%2 == 0){
    echo "divisivel por 2\n";
}else{
    echo "não e divisivel por nenhum valor";
}



?>