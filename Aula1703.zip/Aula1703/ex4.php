<?php 

$nome = "jonathan";
$sexo = "masculino";
$idade = 21;

if($sexo == "masculino" && $idade > 25){
    echo $nome , " aceito";
}else {
    echo $nome , " não aceito";
}




?>