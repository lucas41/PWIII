<?php

$num = 5;

for($i=1; $i<11; $i++){

$val = $num * $i;
echo "o valor de ", $num, " x ", $i, " é igual a: ", $val, "<br>";

}


?>