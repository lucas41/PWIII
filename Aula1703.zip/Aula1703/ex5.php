<?php
    $array = array('1', '2', '3');
    rsort($array); 

    print_r($array);
?>