<?php

$n1 = 2;
$n2 = 2;
$soma = $n1 + $n2;




if($soma > 20){
    $resultfinal = $soma + 8;
    echo $resultfinal;
} else {
    $resultfinal = $soma - 5;
    echo $resultfinal;
}

?>